# APII CRAWLER


## Requirements
https://github.com/apiiphim/apii-core-laravel

## Install
- Tại thư mục của Project: `composer require apiiphim/apii-core-laravel`

## Update
- Tại thư mục của Project: `composer update apiiphim/apii-core-laravel`

## Setup Crontab
[Setup crontab, add this entry](https://github.com/apiiphim/apii-core-laravel#reset-view-counter)

## Changelog
### 1.1.0
- Update crawler schedule
### 1.0.3
- Fix Logic save field crawler
### 1.0.2
- enable check hasChange
### 1.0.1
- Fix sync episodes
### 23/09/2022
- Ghi nhớ fields crawl + download images
- Fix crawl pages hạn chế timeout khi nhiều page

### 22/09/2022
- Thêm lọc bỏ qua theo định dạng
- Tạo thể loại đối với định dạng là `hoạt hình` và `tv shows`
