<?php

namespace Apii\Crawler\ApiiCrawler;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as SP;
use Apii\Crawler\ApiiCrawler\Console\CrawlerScheduleCommand;
use Apii\Crawler\ApiiCrawler\Option;

class ApiiCrawlerServiceProvider extends SP
{
    /**
     * Get the policies defined on the provider.
     *
     * @return array
     */
    public function policies()
    {
        return [];
    }

    public function register()
    {

        config(['plugins' => array_merge(config('plugins', []), [
            'apiiphim/apii-core-laravel' =>
            [
                'name' => 'Apii.Online Crawler',
                'package_name' => 'apiiphim/apii-core-laravel',
                'icon' => 'la la-code-fork',
                'entries' => [
                    ['name' => 'Crawler', 'icon' => 'la la-hand-grab-o', 'url' => backpack_url('/plugin/apii-crawler')],
                    ['name' => 'Option', 'icon' => 'la la-cog', 'url' => backpack_url('/plugin/apii-crawler/options')],
                ],
            ]
        ])]);

        config(['logging.channels' => array_merge(config('logging.channels', []), [
            'apii-crawler' => [
                'driver' => 'daily',
                'path' => storage_path('logs/apiiphim/apii-core-laravel.log'),
                'level' => env('LOG_LEVEL', 'debug'),
                'days' => 7,
            ],
        ])]);

        config(['apii.updaters' => array_merge(config('apii.updaters', []), [
            [
                'name' => 'Apii Crawler',
                'handler' => 'Apii\Crawler\ApiiCrawler\Crawler'
            ]
        ])]);
    }

    public function boot()
    {
        $this->commands([
            CrawlerScheduleCommand::class,
        ]);

        $this->app->booted(function () {
            $this->loadScheduler();
        });

        $this->loadRoutesFrom(__DIR__ . '/../routes/web.php');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'apii-crawler');
    }

    protected function loadScheduler()
    {
        $schedule = $this->app->make(Schedule::class);
        $schedule->command('apii:plugins:apii-crawler:schedule')->cron(Option::get('crawler_schedule_cron_config', '*/10 * * * *'))->withoutOverlapping();
    }
}
